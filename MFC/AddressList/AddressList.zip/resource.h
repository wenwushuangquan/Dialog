﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 AddressList.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_ADDRESSLIST_DIALOG          102
#define IDR_MAINFRAME                   128
#define CHE_REVERSE                     1000
#define EDT_NAME                        1001
#define EDT_TEL                         1002
#define EDT_ADDRESS                     1003
#define CHE_CODE                        1004
#define RAD_MAN                         1005
#define RAD_WOMEN                       1006
#define RAD_UNKNOW                      1007
#define CHE_C                           1008
#define CHE_MFC                         1009
#define LIS_ADDRESSLIST                 1010
#define BTN_ADD                         1011
#define BTN_DELETE                      1012
#define IDC_BUTTON3                     1013
#define BTN_SEARCH                      1013
#define BTN_MODIFY                      1014
#define EDT_SEARCH                      1015
#define STA_TEL                         1016
#define IDC_BUTTON1                     1017

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1018
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
