﻿//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ 生成的包含文件。
// 供 CommonControl.rc 使用
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_COMMONCONTROL_DIALOG        102
#define IDR_MAINFRAME                   128
#define EDT_NAME                        1000
#define RAD_MAN                         1003
#define RAD_WOMEN                       1004
#define RAD_OTHER                       1005
#define RAD_UNKONW                      1006
#define CEK_CODE                        1007
#define CEK_REVERSE                     1008
#define CEK_DEBUG                       1009
#define LIS_TEST                        1012
#define COM_FROM                        1015
#define BTN_SELECTED                    1016
#define BTN_ADD                         1017
#define BTN_DELETE                      1018
#define BTN_TEST                        1019
#define BTN_MODIY                       1020

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        130
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1020
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
